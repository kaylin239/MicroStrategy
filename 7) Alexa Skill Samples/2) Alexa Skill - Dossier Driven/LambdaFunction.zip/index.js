'use strict';
const Alexa = require('alexa-sdk');
var http = require('http'),
    https = require('https');

var aws = require('aws-sdk');
var lambda = new aws.Lambda({
    region: 'us-east-1' //change to your region
});


var config = {
    "projectID": "B7CA92F04B9FAE8D941C3E9B7E0CD754",
    "username" : "myuser",
    "password": "mypass",
    "webserver" : "env-127948.customer.cloud.microstrategy.com",
    "dossierID" : "09B04C9611E9975976360080EFA5B5FD"
};

const APP_ID = undefined;

//=========================================================================================================================================
//Editing anything below this line might break your skill.
//=========================================================================================================================================

const handlers = {
     'myIntent': function () {
        handleRequestData(this);
    },
    'AMAZON.HelpIntent': function () {
        const speechOutput = "help";
        const reprompt = "help";

        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },
    'AMAZON.CancelIntent': function () {
        this.response.speak("stop");
        this.emit(':responseReady');
    },
    'AMAZON.StopIntent': function () {
        this.response.speak("stop");
        this.emit(':responseReady');
    }
};

function getRestSession(me,session,config, callback){
    
  
    var post_data = '{\"username\": \"'+config.username+'\",\"password\": \"'+config.password+'\"}';

    console.log(post_data);

  // An object of options to indicate where to post to
  var post_options = {
      host: config.webserver,
      port: '443',
      path: '/MicroStrategyLibrary/api/auth/login',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
      }
  };
  
  console.log(post_options);

    var responseString = '';
    
  // Set up the request
  var post_req = https.request(post_options, function(res) {
      res.setEncoding('utf8');
      res.on('data', function (chunk) {
          responseString += chunk;
      });
      res.on('end', function () {
          
          if (res.statusCode == 204){
              console.log(res.headers);
              var cookie = res.headers['set-cookie'];
              var token = res.headers['x-mstr-authtoken'];
              callback(null, token, cookie);
          }
          else{
              var speechOutput = "The cloud server " + config.cloudEnvNumber + " is running, but there was an error creating a session. Please check your credentials and try again.";
                me.emit(':tell', speechOutput, speechOutput);    
                return;
          }
      });
  });

  // post the data
  post_req.write(post_data);
  post_req.end();
        

   
  
}
function getDossierDefinition(token,cookie,config, callback){
    console.log("Get dossier definition:");

    var projectID = config.projectID;
    
    var post_data = '';
    
     // An object of options to indicate where to post to
  var post_options = {
      host:config.webserver,
      port: '443',
      path: '/MicroStrategyLibrary/api/dossiers/'+config.dossierID+'/definition',
      method: 'GET',
      headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-MSTR-AuthToken':token,
          'X-MSTR-ProjectID':projectID,
          'cookie': cookie[0]
      }
  };
  
  //console.log(post_options);

    var responseString = '';
    
  // Set up the request
  var post_req = https.request(post_options, function(res) {
      res.setEncoding('utf8');
      res.on('data', function (chunk) {
          responseString += chunk;
      });
      res.on('end', function () {
          callback(null, JSON.parse(responseString));
          
      });
  });

  // post the data
  post_req.write(post_data);
  post_req.end();

}
function getVisualizationKeyAndChapeterKeyBasedOnKPIName(kpiName, definition,  callback){
   
    var chapters = definition.chapters;
    
    for (var i = 0; i < chapters.length; i++){
        var chapter = chapters[i];
        
        var pages = chapter.pages;
        
        for (var j = 0; j < pages.length; j++){
            var page = pages[j];
            
            var visualizations = page.visualizations;
            
            for (var k = 0; k < visualizations.length; k++){
                var vis = visualizations[k];
                //console.log(vis.name);
                
                if(vis.name.toLowerCase() == kpiName.toLowerCase()){
                    console.log("FOUND MATCH");
                    return callback(null, vis.key, chapter.key);
                }
            }
        }
    }
    return callback("Could not locate " + kpiName +' in your dossier', null, null);
}
function getDossierInstance(token,cookie,config, callback){
    console.log("Get dossier instance:");

    var projectID = config.projectID;
    
    var post_data = '';
    
     // An object of options to indicate where to post to
  var post_options = {
      host:config.webserver,
      port: '443',
      path: '/MicroStrategyLibrary/api/dossiers/'+config.dossierID+'/instances',
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-MSTR-AuthToken':token,
          'X-MSTR-ProjectID':projectID,
          'cookie': cookie[0]
      }
  };
  
  //console.log(post_options);

    var responseString = '';
    
  // Set up the request
  var post_req = https.request(post_options, function(res) {
      res.setEncoding('utf8');
      res.on('data', function (chunk) {
          responseString += chunk;
      });
      res.on('end', function () {
          
         //console.log(responseString);
         
         var response = JSON.parse(responseString);
         console.log(response);
          callback(null, response['mid']);
          
      });
  });

  // post the data
  post_req.write(post_data);
  post_req.end();

}
function getVisData(token,cookie,instanceID, visKey, chapterKey,config,  callback){
    console.log("Get vis data:");

    var projectID = config.projectID;
    
    var post_data = '';
    
     // An object of options to indicate where to post to
  var post_options = {
      host:config.webserver,
      port: '443',
      path: '/MicroStrategyLibrary/api/dossiers/'+config.dossierID+'/instances/'+instanceID+'/chapters/'+chapterKey+'/visualizations/'+visKey,
      method: 'GET',
      headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-MSTR-AuthToken':token,
          'X-MSTR-ProjectID':projectID,
          'cookie': cookie[0]
      }
  };
  
  //console.log(post_options);

    var responseString = '';
    
  // Set up the request
  var post_req = https.request(post_options, function(res) {
      res.setEncoding('utf8');
      res.on('data', function (chunk) {
          responseString += chunk;
      });
      res.on('end', function () {
          
         //console.log(responseString);
         
         var response = JSON.parse(responseString);
         console.log(response);
          callback(null, response);
          
      });
  });

  // post the data
  post_req.write(post_data);
  post_req.end();

}

function handleRequestData(me){
        var kpi = "";
      
      let skillId, requestType, dialogState, intent ,intentName, intentConfirmationStatus, slotArray, slots, count;

        
        
    
        getRestSession(me, me.event.session,config, function (err, token, cookie){
            console.log("Token: " + token);
            console.log("Cookie: " + cookie);
            
            var kpi = me.event.request.intent.slots["Slot"].value;
                
            
            getDossierDefinition(token, cookie, config, function (err, definition){
                
                
                
                console.log("CLEANSED KPI: " + kpi);
                getVisualizationKeyAndChapeterKeyBasedOnKPIName(kpi, definition, function (err, visKey, chapterKey){
                    console.log("Error: " + err);
                    console.log("VisKey:" + visKey);
                    console.log("ChapterKey: " + chapterKey);
                    
                    if(err){
                         var speechOutput = err;
                        me.response.speak(speechOutput);
                        me.emit(':responseReady');
                        return;
                    }
                    
                    getDossierInstance(token, cookie,config, function (err,instanceID){
                        console.log("instanceID: " + instanceID);
                        
                        getVisData(token,cookie,instanceID, visKey, chapterKey, config,  function(err, data){
                            
                            var metrics = data.result.data.root.metrics;
                            
                            
                            
                            var metricData = metrics[Object.keys(metrics)[0]].fv;
                            console.log("Metric Data:" + metricData);
                            
                            var speechOutput = metricData;
                            //me.response.speak("Your value for " + kpi + " is " + metricData);
                            me.response.speak(metricData);
                            me.emit(':responseReady');    
                        }); 
                    });
                    
                });
                
                
                
                
            });
           
            
        });
        
       
}


exports.handler = function (event, context, callback) {
    const alexa = Alexa.handler(event, context, callback);
    alexa.APP_ID = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};